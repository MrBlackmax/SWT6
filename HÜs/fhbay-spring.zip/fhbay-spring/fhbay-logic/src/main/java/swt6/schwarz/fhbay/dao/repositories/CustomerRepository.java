package swt6.schwarz.fhbay.dao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import swt6.schwarz.fhbay.dao.domain.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

 /*   public Customer findById(long customerId) {
        try {
            var query = getEm().createQuery("select c from Customer c where c.id = :id", Customer.class);
            query.setParameter("id", customerId);
            return query.getResultList().stream().findFirst().orElse(null);
        } catch (Exception ex) {
            DaoUtils.rollback();
            throw ex;
        }
    }*/
}
