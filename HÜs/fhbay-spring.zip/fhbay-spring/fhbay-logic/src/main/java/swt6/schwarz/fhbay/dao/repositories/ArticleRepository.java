package swt6.schwarz.fhbay.dao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import swt6.schwarz.fhbay.dao.domain.Article;

import java.util.List;

@Repository
public interface ArticleRepository extends JpaRepository<Article, Long> {

    @Query("select a from Article a where a.title LIKE %:term% OR a.description LIKE %:term%")
    public List<Article> findByTerm(@Param("term") String searchTerm);


    //gets price highest bid amount or initial price if no bids
  /*  public double getCurrentPrice(Article article) {
        try {
            var cb = getEm().getCriteriaBuilder();
            var query = cb.createQuery(Bid.class);
            var root = query.from(Bid.class);
            var param = cb.parameter(Article.class);
            query.where(cb.equal(root.get(Bid_.article), param)).select(root);
            var entryQuery = getEm().createQuery(query);
            entryQuery.setParameter(param, article);
            var foundBids= entryQuery.getResultList();
            if (foundBids.size()  == 0) {
                return article.getInitialPrice();
            } else {
                return foundBids.stream().mapToDouble(b -> b.getAmount()).max().orElse(article.getInitialPrice());
            }
        } catch (Exception ex) {
            DaoUtils.rollback();
            throw ex;
        }
    }*/
}
