# FH Bay
## by Maximilian Schwarz

### Diagramme
- ![ER Diagramm](erdiagram.png)
- ![UML Diagramm](umldigram.png)